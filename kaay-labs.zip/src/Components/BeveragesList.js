import React,{useEffect, useState} from 'react'
import axios from 'axios';
import Pagination from '../Pagination.js/Pagination';
import {useSelector} from 'react-redux';


const BeveragesList = () => {
    const currentItems=useSelector((state)=>state);
    const [beveragesList, setBeveragesList] = useState([]);
    const[searchName,setSearchName]=useState("")
    
    //------------------------------------ API -----------------------------------------
    useEffect(()=>{
        const fetchApi=async()=>{
            await axios.get("https://api.punkapi.com/v2/beers?page=1&per_page=10").then(res=>setBeveragesList(res.data))
        }
        fetchApi();
    },[]);
 //------------------------------------ Filter -----------------------------------------
   const searchChange=(e)=>{
    setSearchName(e.target.value)
   }

//    --------------------------------Pagination ------------------------------------------

  return (
    <>
   <div className='main-page'>
   <div className='header'>
        <h4>List of Beverages</h4>
    </div>
    {/*---------------------------- Filter-------------------------- */}
    <div className='filter-section'>
        <div className='custom-input'>
            <input placeholder='Search by name' onChange={searchChange} type="text"/>
        </div>
    </div>
    {/* ----------------------------Table---------------------------- */}
    <div className='table-responsive'>
    <table className="table table-striped table-hover">
    <thead>
        <tr>
        <th >#</th>
        <th >First</th>
        <th >Last</th>
        <th >Handle</th>
        </tr>
    </thead>
    <tbody>
    {beveragesList.length?(beveragesList.filter((data) => {
                        if (searchName === "") {
                          return data;
                        }
                        else if (data.name.toLowerCase().includes(searchName.toLowerCase())) {
                          return data;
                        }
                      }).map((data,index)=>{
                            return(
                                <tr key={index} >
                        <td >{data.id}</td>
                        <td>{data.ph}</td>
                        <td>{data.name}</td>
                        <td>{data.tagline}</td>
                        </tr>
                        )
                    })):(
                        <tr>
                        <td colSpan="4">
                        <div className="loading-gif">
                            <span className="loader">
                            <span className="loader-inner"></span>
                            </span>
                        </div>
                        </td>
                    </tr>
                    )}
    </tbody>
    </table>
  
    </div>
    <Pagination/>
     
   </div>
    </>
  )
}

export default BeveragesList