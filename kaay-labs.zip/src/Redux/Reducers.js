import React, { useEffect, useState } from 'react'
import axios from 'axios'

const Reducers = (curr=[],action) => {
   

  
    if(action.type==="CHANGE"){
       console.log(action.payload)
    }
  return (
    <>
    
    </>
  )
}

export default Reducers