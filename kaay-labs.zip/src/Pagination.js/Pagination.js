import React,{useState,useEffect} from 'react';
import {useDispatch} from 'react-redux';
import axios from 'axios'

const Pagination = () => {
    const dispatch=useDispatch();
//     const[beveragesList,setbeveragesList]=useState([])
//     const [currentPage, setCurrentPage] = useState(1);
//     const [itemsPerPage, setItemPerPage] = useState(10);

    
//     useEffect(()=>{
//         const fetchAPI=async()=>{
//             await axios.get(`https://api.punkapi.com/v2/beers?page=${currentPage}&per_page=${itemsPerPage}`).then(res=>setbeveragesList(res.data))
//         }
//     fetchAPI();
//     },[]);
// console.log(beveragesList);
 

  return (
    <>
     {/* --------------------Pagination------------------- */}
     <div className="pagination-sec d-flex justify-content-between align-items-center mt-2">
              <div className="page-size d-flex align-items-center">
                <span>Show</span>
                <div className="custom-select">
                  <select onChange={(e)=>{dispatch({type:"CHANGE",payload:e.target.value})}}  name="pageSize">
                    <option name="five" value="5">5</option>
                    <option name="ten" value="10">10</option>
                  </select>
                  {/* <img src={countArrow} alt="count-arrow" /> */}
                </div>
                <span>of Total Entries</span>
              </div>
              {/* <div className="page-numbers">
                <ul>
                  <li>
                    <button className="pagination-prev-btn" onClick={handlePrevBtn} disabled={currentPage === pages[0] ? true : false}> Prev.</button>
                  </li>
                  {pages.map((num, index) => {
                    if (num <= maxPageNumberLimit && num >= minPageNumberLimit) {
                      return (
                        <li key={index} id={num} onClick={() => {pageChangeClick(index)}} className={currentPage === num ? "active" : ""}>
                          {num}
                        </li>
                      );
                    }
                  })}
                  {postIncrementBtn}
                  <li>
                    <button className="pagination-next-btn" onClick={handleNextBtn} disabled={currentPage === pages[pages.length - 1] ? true : false}>
                      Next
                    </button>
                  </li>
                </ul>
              </div> */}
            </div>

    </>
  )
}

export default Pagination
