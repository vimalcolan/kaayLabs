import BeveragesList from "./Components/BeveragesList";
import './App.css'

function App() {
  return (
    <div className="App">
    <BeveragesList/>
    </div>
  );
}

export default App;
